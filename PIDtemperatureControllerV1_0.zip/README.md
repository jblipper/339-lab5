# PID-Temperature-Controller
Code for the PID temperature controller lab in the Physics 339 laboratory course at McGill university.

![](https://github.com/BrandonRuf/PID-Temperature-Controller/blob/master/Images/GUI.PNG)
